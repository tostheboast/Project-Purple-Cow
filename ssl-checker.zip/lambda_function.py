import json
import ssl
import socket
import datetime

def ssl_expiry_datetime(host, port):
    ssl_date_fmt = r'%b %d %H:%M:%S %Y %Z'

    context = ssl.create_default_context()
    conn = context.wrap_socket(
        socket.socket(socket.AF_INET),
        server_hostname=host,
    )

	# lambda times out after 3 seconds
    conn.settimeout(3.0)
    conn.connect((host, port))
    ssl_info = conn.getpeercert()
	# print out all ssl cert information including DNS, subdomains, and ca-issues related to the cert to the function log
    print(ssl_info)
    # parsing the string from the certificate into a Python datetime object 
    result = datetime.datetime.strptime(ssl_info['notAfter'], ssl_date_fmt)
    return result
    
def lambda_handler(event, context):
   
    # change this to the host website of your choice. to test an invalid cert use 'expired.badssl.com'
    host = "google.com"


    response = ""
    
    
   
    try:
         # good and valid SSL response message
        response = "The SSL Certificate for %s is currently VALID and expires on: %s"%(host, ssl_expiry_datetime(host, 443))
        
    except:
        #catching invalid cert error to instead output a response message
        response = "The SSL Certificate for %s is INVALID and possibly past "%host

    
    
    return {
        'statusCode': 200,
        'body': json.dumps(response, default=str)
    }
